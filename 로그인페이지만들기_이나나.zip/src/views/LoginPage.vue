<template>

    <div> 
        <!--input type="test" :placeholer="email" v-model="email">
        <input type="password" :placeholer="password" v-mode="password"/-->
        <InputField :type="'text'" :placeholder="'Email'" :modelValue="email" v-model="email"/>
        <InputField :type="'password'" :placeholder="'Password'" :modelValue="password" v-model="password"/>
        <button class="login-button" v-on:click="login">로그인하기</button>
    </div>
    <div>
        계정이 없으신가요?
        <span class="signup-button">가입하기</span>
    </div>

</template>

<script>
import InputField from '@/components/InputField.vue';

export default {
    name: "LoginPage",
    components: {InputField},
    data() {
        return {
            email: "",
            password: "",
        };
    },
    methods: {
        login() {
            console(this.email, this);
        }
    },
};
</script>

<style scoped>
    .login-button{
        border-radius: 20px;
        border: 1px solid white;
        font-size: 15px;
        font-weight:bold;
        margin: 10px 0px;
        padding: 10px;
        width: 100%;
        cursor: pointer;
    }
    .signup-button{
        color: aqua;
        cursor: pointer;
    }
</style>