<template>
  <h1>hello world</h1>
</template>

<script>

export default {
  name: 'App',

}
</script>

<style>
</style>
